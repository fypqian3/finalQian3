package com.counter.app.ui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.counter.app.R;
import com.counter.app.lib.db.Database;
import com.counter.app.lib.db.DatabaseItem;

import org.eazegraph.lib.charts.BarChart;
import org.eazegraph.lib.models.BarModel;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class StatsAct extends Activity {


    private TextView record, totalThisWeek, totalThisMonth, averageThisWeek, averageThisMonth;
    private static int currStep;
    SharedPreferences mSharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        record = (TextView) findViewById(R.id.record);
        totalThisWeek = (TextView) findViewById(R.id.totalthisweek);
        totalThisMonth = (TextView) findViewById(R.id.totalthismonth);
        averageThisWeek = (TextView) findViewById(R.id.averagethisweek);
        averageThisMonth = (TextView) findViewById(R.id.averagethismonth);

    }

    @Override
    protected void onStart() {
        super.onStart();
        // Bind with the service


        Database db = Database.getInstance(this);
        Calendar fromDay = Calendar.getInstance();
        fromDay.add(Calendar.DATE, -8);
        Calendar endDay = Calendar.getInstance();
        endDay.add(Calendar.DATE, -1);
        int daysThisMonth = endDay.get(Calendar.DAY_OF_MONTH);
       //currStep = mSharedPreferences.getInt("data_currSteps", 0);
        DatabaseItem[] maxSteps;
        maxSteps = db.getMaxSteps(1);
        record.setText(String.valueOf(maxSteps[0].steps) + " steps at " + String.valueOf(maxSteps[0].getYear()) + " / " +
                String.valueOf(maxSteps[0].getMonth()) + " / " + String.valueOf(maxSteps[0].getDay()));

        totalThisWeek.setText(String.valueOf(db.getStepSum(fromDay, endDay)) + " steps");
        fromDay.set(Calendar.DATE, 1);
        totalThisMonth.setText(String.valueOf(db.getStepSum(fromDay, endDay)) + " steps");
        averageThisWeek.setText(String.valueOf(db.getStepSum(fromDay, endDay) / 7) + " steps");
        averageThisMonth.setText(String.valueOf(db.getStepSum(fromDay, endDay)/ daysThisMonth) + " steps");

        db.close();
        barChart();


    }

    @Override
    protected void onStop() {
        super.onStop();


    }

    private void barChart(){
        Database db = Database.getInstance(this);
        Calendar sevenDayBefore = Calendar.getInstance();
        sevenDayBefore.add(Calendar.DATE, -6);

        int step;
        BarModel bm;
        BarChart barChart = (BarChart) findViewById(R.id.bargraph);
        if (barChart.getData().size() > 0)
            barChart.clearChart();
        SimpleDateFormat df = new SimpleDateFormat("dd MMM");
        for(int i = 0; i < 7; i++){
            step = db.getSteps(sevenDayBefore);
            if (step > 0) {
                Date day = sevenDayBefore.getTime();
                bm = new BarModel(df.format(day), 0,  Color.parseColor("#99CC00"));
                bm.setValue(step);
                barChart.addBar(bm);
            }
            sevenDayBefore.add(Calendar.DATE, 1);
        }

        if(barChart.getData().size() > 0){
            barChart.startAnimation();
        }
        else
        {
            barChart.setVisibility(View.GONE);
        }

        db.close();


    }
}