package fyp.qian3.ui;

import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.akexorcist.roundcornerprogressbar.RoundCornerProgressBar;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookSdk;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;

import fyp.qian3.R;
import fyp.qian3.lib.srv.PedoEvent;
import fyp.qian3.lib.srv.PedoEventService;

public class HomeAct extends AppCompatActivity implements PedoEvent.onPedoEventListener, NavigationView.OnNavigationItemSelectedListener, Animation.AnimationListener {

    boolean mPedoSrvBound;
    SharedPreferences sharedPrefs;
    PedoEvent mPedoEvent;
    ServiceConnection mConnection;
    // Binder is used to call service function
    PedoEventService.PedoSrvBinder mPedoSrvBinder;

    CallbackManager callbackManager;
    private AccessToken accessToken;
    TextView tvCurrStep;
    ShareDialog shareDialog;
    int enemyLevel = 1;
    ImageButton imageButton1;
    ImageButton imageButton2;
    ImageButton imageButton3;

    Animation animBlink;
    ImageView image;

    int diamond;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        FacebookSdk.sdkInitialize(getApplicationContext());

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_drawer);


        init();
        initDrawer();
        enemyShow();
        monsterEat();
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Bind with the service
        bindService(new Intent(this, PedoEventService.class), mConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();

        // Unbind from the service
        if (mPedoSrvBound) {
            unbindService(mConnection);
            mPedoSrvBound = false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onPedoDetected() {
        if (mPedoSrvBound) {
            tvCurrStep.setText(String.valueOf(mPedoSrvBinder.getCurrStep()));
        } else {
            Log.e("HomeAct", "Error: Service not bound!");
        }
    }

    private void init() {

        tvCurrStep = (TextView) findViewById(R.id.tvHomeCurrStep);

        /***** Set Parameters *****/
        // For determine whether current activity is connecting to service or not
        mPedoSrvBound = false;
        // Get shared preference
        sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        // Define  PedoEvent for PedoEventListener, so that onPedoDetected() could work correctly
        mPedoEvent = new PedoEvent(this);
        // Defines callbacks for service binding, passed to bindService()
        mConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName className, IBinder service) {
                mPedoSrvBound = true;
                mPedoSrvBinder = (PedoEventService.PedoSrvBinder) service;
                // Pass current ui  PedoEvent to the service so that  onPedoDetected() could be triggered.
                mPedoSrvBinder.setPedoEvent(mPedoEvent);
                tvCurrStep.setText(String.valueOf(mPedoSrvBinder.getCurrStep()));

            }

            @Override
            public void onServiceDisconnected(ComponentName arg0) {
                mPedoSrvBound = false;
            }
        };
    }

    private void initDrawer() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener((NavigationView.OnNavigationItemSelectedListener) this);
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_about) {
            enableAboutUs();
        } else if
                (id == R.id.nav_achievement) {
            startActivity(new Intent(HomeAct.this, fyp.qian3.ui.AchievementAct.class));
        } else if (id == R.id.nav_share)

        {
            enableShare();
        } else if (id == R.id.nav_home)

        {
            startActivity(new Intent(HomeAct.this, fyp.qian3.ui.HomeAct.class));
        } else if (id == R.id.nav_history)

        {
            startActivity(new Intent(HomeAct.this, fyp.qian3.ui.HistoryAct.class));
        } else if (id == R.id.nav_chart)

        {
            startActivity(new Intent(HomeAct.this, fyp.qian3.ui.StatsAct.class));
        } else if (id == R.id.nav_leaderboard)

        {
            startActivity(new Intent(HomeAct.this, fyp.qian3.ui.LeaderboardAct.class));
        } else if (id == R.id.nav_me)

        {
            startActivity(new Intent(HomeAct.this, fyp.qian3.ui.MeAct.class));
        } else if (id == R.id.nav_setting)

        {
            startActivity(new Intent(HomeAct.this, fyp.qian3.ui.SettingAct.class));
        } else if (id == R.id.nav_faq)

        {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://www.google.com.hk"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }


    DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
    drawer.closeDrawer(GravityCompat.START);
    return true;
}

    public void enableShare() {
        ShareLinkContent content = new ShareLinkContent.Builder()
                .setContentUrl(Uri.parse("https://developers.facebook.com"))
                .build();

        callbackManager = CallbackManager.Factory.create();
        shareDialog = new ShareDialog(this);
        // this part is optional
        if (ShareDialog.canShow(ShareLinkContent.class)) {
            ShareLinkContent linkContent = new ShareLinkContent.Builder()
                    .setContentTitle("Counter Monster")
                    .setContentDescription(
                            "Hello Every,I am using Counter Monster App")
                    .setContentUrl(Uri.parse("http://developers.facebook.com/android"))
                    .build();

            shareDialog.show(linkContent);
        }
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    public void enableAboutUs() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("About Us");
        TextView tv = new TextView(this);
        tv.setPadding(10, 10, 10, 10);
        tv.setText(R.string.about_text_links);

        tv.setMovementMethod(LinkMovementMethod.getInstance());
        builder.setView(tv);
        builder.setPositiveButton(android.R.string.ok,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(final DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        builder.create().show();
    }

    public void enemyBar() {
        RoundCornerProgressBar bar = (RoundCornerProgressBar) findViewById(R.id.enemyBar);
        if (enemyLevel == 1) {
            int max = 5000;
            int progress = 0;
            bar.setMax(max);
            // the progress according to the onstepchange like progress=(onstepchange)
            bar.setProgress(progress);
        }
    }

    public void enemyShow() {
        final Dialog settingsDialog = new Dialog(this);
        imageButton1 = (ImageButton) findViewById(R.id.home);

        imageButton1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                settingsDialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
                settingsDialog.setContentView(getLayoutInflater().inflate(R.layout.image_layout
                        , null));
                settingsDialog.show();
            }

        });

    }

    public void monsterEat() {
        imageButton2 = (ImageButton) findViewById(R.id.eat);
        animBlink = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.blink);
        image = (ImageView) findViewById(R.id.monster);

        // set animation listener
        animBlink.setAnimationListener(this);

        imageButton2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                v.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.image_click));

                // start the animation
                image.startAnimation(animBlink);

            }

        });

    }

    public void monsterUpgrade() {
        imageButton3 = (ImageButton) findViewById(R.id.upgrade);
        imageButton3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (diamond > 10000) {
                    diamond -= 10000;

                }
            }

        });

    }


    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}